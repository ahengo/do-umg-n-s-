Merhaba aşko!

Bu dosyalar doğum günü oyunun için hazırlanmıştır.

Nasıl kullanılır:

1. Github hesabına giriş yap veya ücretsiz aç.
2. Yeni repository oluştur.
3. Bu klasördeki dosyaları repository'ne yükle.
4. Repository ayarlarından (Settings > Pages) GitHub Pages'i aktif et.
5. Site adresi (link) oluşacak, o linke tıklayarak oyunu açabilirsin.
6. Linki sevgiline gönder, oyunu tarayıcıda oynayabilir.

Kolay gelsin! ❤️
